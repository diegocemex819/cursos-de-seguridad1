
import React from 'react';
import { VERIFICACIONES_INITIATIVES } from '../constants';
import InitiativeCard from './InitiativeCard';

const FlowStep: React.FC<{ title: string; description: string; className?: string }> = ({ title, description, className = '' }) => (
    <div className={`bg-white p-4 rounded-lg shadow-md text-center relative w-full md:w-1/4 ${className}`}>
        <span className="font-bold text-blue-600 block mb-1">{title}</span>
        <span className="text-sm text-gray-700">{description}</span>
    </div>
);

const FlowArrow: React.FC = () => (
    <div className="flex items-center justify-center text-3xl text-gray-400 mx-2 transform md:rotate-0 rotate-90">
        →
    </div>
);

const VerificacionesSection: React.FC = () => {
    return (
        <section>
            <div className="text-left max-w-3xl mx-auto mb-8">
                <h2 className="text-2xl font-semibold text-gray-800 mb-3">Candados para Verificaciones (Garantía de Presencia Física)</h2>
                <p className="text-gray-600">El objetivo es hacer la verificación dependiente de la confirmación digital e inalterable de la unidad en el sitio de inspección. A continuación se presentan 3 iniciativas clave y su flujo de proceso.</p>
            </div>
            
            <div className="grid md:grid-cols-1 lg:grid-cols-3 gap-6 mb-12">
                {VERIFICACIONES_INITIATIVES.map(initiative => (
                    <InitiativeCard key={initiative.id} initiative={initiative} />
                ))}
            </div>

            <div>
                <h3 className="text-xl font-semibold text-gray-800 mb-6 text-center">Flujo del Proceso de Verificación Segura</h3>
                <div className="flex flex-col md:flex-row items-center justify-center space-y-4 md:space-y-0 md:space-x-4">
                    <FlowStep title="Paso 1" description="Unidad llega y escanea ID (Iniciativa 4)" />
                    <FlowArrow />
                    <FlowStep title="Paso 2" description="Inspector toma fotos con App (Iniciativa 5)" />
                    <FlowArrow />
                    <FlowStep title="Paso 3" description="Sistema valida cita y datos (Iniciativa 6)" />
                    <FlowArrow />
                    <div className="bg-green-100 p-4 rounded-lg shadow-md text-center relative w-full md:w-1/4">
                        <span className="font-bold text-green-800 block mb-1">Resultado</span>
                        <span className="text-sm text-green-800">Inspección iniciada o marcada como ausente.</span>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default VerificacionesSection;
