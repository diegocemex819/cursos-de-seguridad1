
import React from 'react';
import { Initiative } from '../types';

interface InitiativeCardProps {
    initiative: Initiative;
}

const InitiativeCard: React.FC<InitiativeCardProps> = ({ initiative }) => {
    return (
        <div className="bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl flex flex-col">
            <div className="p-6 flex items-center space-x-4">
                <div className="text-4xl flex-shrink-0 w-16 h-16 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center">
                    {initiative.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-800">{initiative.title}</h3>
            </div>
            <div className="px-6 pb-6 text-gray-700 space-y-3">
                <p className="font-medium text-gray-800">{initiative.subtitle}</p>
                <ul className="list-disc list-inside space-y-2">
                    {initiative.points.map((point, index) => (
                        <li key={index} dangerouslySetInnerHTML={{ __html: point }}></li>
                    ))}
                </ul>
            </div>
        </div>
    );
};

export default InitiativeCard;
