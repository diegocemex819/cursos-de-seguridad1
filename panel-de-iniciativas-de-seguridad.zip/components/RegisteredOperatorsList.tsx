import React from 'react';
import { RegisteredOperator } from '../types';

declare global {
    interface Window {
        jspdf: any;
    }
}

interface RegisteredOperatorsListProps {
    operators: RegisteredOperator[];
}

const RegisteredOperatorsList: React.FC<RegisteredOperatorsListProps> = ({ operators }) => {

    const exportToPDF = () => {
        if (!window.jspdf) {
            alert("Error: La librería para generar PDF no está cargada.");
            return;
        }
        
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();

        // Title
        doc.setFontSize(18);
        doc.text("LISTA DE ASISTENCIA", 105, 15, { align: 'center' });
        doc.setFontSize(10);
        doc.setTextColor(100);
        doc.text(`Generado el: ${new Date().toLocaleString('es-MX')}`, 200, 15, { align: 'right' });


        // Table Headers
        const headers = [
            { title: "Foto", x: 15 },
            { title: "ID Operador", x: 40 },
            { title: "Nombre Completo", x: 70 },
            { title: "Empresa", x: 120 },
            { title: "Fecha/Hora Registro", x: 170 }
        ];
        
        const startY = 25;
        const rowHeight = 20; // Increased height for photo
        const pageHeight = doc.internal.pageSize.height;
        let y = startY;

        const drawHeader = (currentY: number) => {
             doc.setFontSize(10);
             doc.setFont(undefined, 'bold');
             headers.forEach(header => {
                doc.text(header.title, header.x, currentY);
             });
             doc.line(10, currentY + 2, 200, currentY + 2); // Underline headers
             doc.setFont(undefined, 'normal');
        };

        drawHeader(y);
        y += 7; // space after header

        operators.forEach((op, index) => {
            if (y + rowHeight > pageHeight - 15) { // Check for page break
                doc.addPage();
                y = startY;
                drawHeader(y);
                y += 7;
            }

            // Add Image
            try {
                doc.addImage(op.photo, 'JPEG', 15, y, 15, 15); // x, y, width, height
            } catch (e) {
                console.error(`Error adding image for ${op.name}:`, e);
                doc.text("Error", 15, y + 9);
            }

            // Add Text
            doc.setFontSize(9);
            doc.text(op.id, 40, y + 9);
            doc.text(op.name, 70, y + 9);
            doc.text(op.transportista, 120, y + 9);
            doc.text(new Date(op.timestamp).toLocaleString('es-MX'), 170, y + 9);
            
            y += rowHeight;
        });

        doc.save("lista_de_asistencia_con_fotos.pdf");
    };

    return (
        <div className="p-6 bg-gray-50 rounded-lg shadow-inner border">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-semibold text-gray-800">LISTA DE ASISTENCIA</h3>
                {operators.length > 0 && (
                     <button 
                        onClick={exportToPDF}
                        className="px-4 py-2 bg-red-700 text-white rounded-md hover:bg-red-800 text-sm font-medium"
                    >
                        Exportar a PDF
                    </button>
                )}
            </div>
            
            {operators.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No hay operadores registrados aún.</p>
            ) : (
                <div className="overflow-x-auto">
                    <table className="min-w-full bg-white rounded-lg shadow">
                        <thead className="bg-gray-100">
                            <tr>
                                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Foto</th>
                                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nombre</th>
                                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Empresa</th>
                                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fecha/Hora Registro</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                            {operators.map(operator => (
                                <tr key={operator.id}>
                                    <td className="px-4 py-2 whitespace-nowrap">
                                        <img src={operator.photo} alt={operator.name} className="w-10 h-10 rounded-full object-cover border" />
                                    </td>
                                    <td className="px-4 py-2 whitespace-nowrap">
                                        <div className="text-sm font-medium text-gray-900">{operator.name}</div>
                                        <div className="text-xs text-gray-500 font-mono">{operator.id}</div>
                                    </td>
                                    <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-700">{operator.transportista}</td>
                                    <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-700">
                                        {new Date(operator.timestamp).toLocaleString('es-MX')}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
};

export default RegisteredOperatorsList;