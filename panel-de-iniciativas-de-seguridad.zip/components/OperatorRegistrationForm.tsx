import React, { useState, useRef, useCallback, useEffect } from 'react';
import { RegisteredOperator, OperatorRecord, QuizQuestion } from '../types';
import { QUIZ_QUESTIONS } from '../quizQuestions';

interface OperatorRegistrationFormProps {
    onRegister: (operator: RegisteredOperator) => void;
    onAddNewOperator: (operator: OperatorRecord) => void;
    operatorDB: OperatorRecord[];
}

const getShuffledQuiz = (count: number): QuizQuestion[] => {
    const shuffled = [...QUIZ_QUESTIONS].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
};

const OperatorRegistrationForm: React.FC<OperatorRegistrationFormProps> = ({ onRegister, onAddNewOperator, operatorDB }) => {
    // Step 1 state
    const [operatorId, setOperatorId] = useState('');
    const [foundOperator, setFoundOperator] = useState<OperatorRecord | null>(null);
    const [idError, setIdError] = useState('');
    const [isNewOperatorMode, setIsNewOperatorMode] = useState(false);
    const [newOperatorName, setNewOperatorName] = useState('');
    const [newOperatorTransportista, setNewOperatorTransportista] = useState('');

    // Step 2 state
    const [isCameraActive, setIsCameraActive] = useState(false);
    const [stream, setStream] = useState<MediaStream | null>(null);
    const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
    const [cameraError, setCameraError] = useState('');
    
    // Step 3 state
    const [currentQuestions, setCurrentQuestions] = useState<QuizQuestion[]>([]);
    const [quizAnswers, setQuizAnswers] = useState<Record<string, string>>({});
    const [quizStatus, setQuizStatus] = useState<'pending' | 'passed' | 'failed'>('pending');

    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    
    const isIdStepComplete = foundOperator !== null || isNewOperatorMode;

    const stopCameraStream = useCallback(() => {
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
            setStream(null);
            setIsCameraActive(false);
        }
    }, [stream]);

    const resetForm = useCallback(() => {
        setOperatorId('');
        setFoundOperator(null);
        setIdError('');
        setIsNewOperatorMode(false);
        setNewOperatorName('');
        setNewOperatorTransportista('');
        setCapturedPhoto(null);
        setCameraError('');
        setQuizStatus('pending');
        setQuizAnswers({});
        setCurrentQuestions([]);
        stopCameraStream();
    }, [stopCameraStream]);

    const handleIdSearch = () => {
        const operator = operatorDB.find(op => op.id.toLowerCase() === operatorId.toLowerCase());
        if (operator) {
            setFoundOperator(operator);
            setIdError('');
            setIsNewOperatorMode(false);
        } else {
            setFoundOperator(null);
            setIdError('ID de operador no encontrado. Puede registrarlo como "Nuevo Ingreso".');
        }
    };
    
    const handleEnableNewOperatorMode = () => {
        setIsNewOperatorMode(true);
        setFoundOperator(null);
        setIdError('');
    };

    useEffect(() => {
        if (isCameraActive && stream && videoRef.current) {
            videoRef.current.srcObject = stream;
        }
        return () => {
            if (stream && !isCameraActive) {
                stopCameraStream();
            }
        };
    }, [isCameraActive, stream, stopCameraStream]);

    const handleStartCamera = async () => {
        setCapturedPhoto(null);
        try {
            setCameraError('');
            const mediaStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" } });
            setStream(mediaStream);
            setIsCameraActive(true);
        } catch (err) {
            setCameraError("No se pudo acceder a la cámara. Verifique los permisos.");
        }
    };
    
    const handleCapturePhoto = () => {
        if (videoRef.current && canvasRef.current) {
            const video = videoRef.current;
            const canvas = canvasRef.current;
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            canvas.getContext('2d')?.drawImage(video, 0, 0, canvas.width, canvas.height);
            setCapturedPhoto(canvas.toDataURL('image/jpeg'));
            stopCameraStream();
            setCurrentQuestions(getShuffledQuiz(3));
        }
    };

    const handleAnswerChange = (question: string, answer: string) => {
        setQuizAnswers(prev => ({ ...prev, [question]: answer }));
    };

    const handleValidateQuiz = () => {
        const allCorrect = currentQuestions.every(q => quizAnswers[q.question] === q.correctAnswer);
        setQuizStatus(allCorrect ? 'passed' : 'failed');
    };
    
    const handleRetryQuiz = () => {
        setQuizStatus('pending');
        setQuizAnswers({});
        setCurrentQuestions(getShuffledQuiz(3));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!capturedPhoto || quizStatus !== 'passed') return;

        let operatorData: OperatorRecord;

        if (isNewOperatorMode) {
             if (!newOperatorName || !newOperatorTransportista) {
                alert("Por favor, complete el nombre y la empresa del nuevo operador.");
                return;
             }
             operatorData = { id: operatorId, name: newOperatorName, transportista: newOperatorTransportista };
             onAddNewOperator(operatorData);
        } else if (foundOperator) {
            operatorData = foundOperator;
        } else {
            return; // Should not happen
        }

        const newRegisteredOperator: RegisteredOperator = {
            ...operatorData,
            photo: capturedPhoto,
            timestamp: Date.now(),
        };
        onRegister(newRegisteredOperator);
        resetForm();
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4 p-4 bg-gray-50 rounded-lg shadow-inner border">
            {/* Step 1: ID Search */}
            <div className={`p-4 rounded-lg border ${isIdStepComplete ? 'bg-green-50 border-green-200' : 'bg-white'}`}>
                <h4 className="font-semibold text-gray-700">Paso 1: Identificación del Operador</h4>
                <div className="mt-2">
                    <label htmlFor="operator-id" className="block text-sm font-medium text-gray-700 mb-1">
                        ID de Operador
                    </label>
                    <div className="flex items-center space-x-2">
                        <input
                            id="operator-id"
                            type="text"
                            value={operatorId}
                            onChange={(e) => setOperatorId(e.target.value.toUpperCase())}
                            placeholder="Ej. MX-CAR-789"
                            className="w-full p-2 border border-gray-300 rounded-md disabled:bg-gray-200"
                            disabled={isIdStepComplete}
                        />
                        <button
                            type="button"
                            onClick={handleIdSearch}
                            disabled={isIdStepComplete || !operatorId}
                            className="action-button-verification"
                        >
                            Buscar
                        </button>
                    </div>
                </div>
                {idError && (
                    <div className="mt-2 text-center">
                        <p className="text-orange-600 text-sm">{idError}</p>
                        <button type="button" onClick={handleEnableNewOperatorMode} className="text-sm text-blue-600 hover:underline mt-1">
                            ¿No está en la lista? <strong>Crear Nuevo Ingreso</strong>
                        </button>
                    </div>
                )}
                {isNewOperatorMode && (
                     <div className="mt-4 space-y-2">
                         <h5 className="font-semibold text-gray-600">Datos del Nuevo Operador</h5>
                         <div>
                             <label className="block text-sm font-medium text-gray-700">ID de Operador</label>
                             <input type="text" value={operatorId} disabled className="mt-1 w-full p-2 border border-gray-300 rounded-md bg-gray-200" />
                         </div>
                         <div>
                            <label htmlFor="new-name" className="block text-sm font-medium text-gray-700">Nombre Completo</label>
                            <input id="new-name" type="text" value={newOperatorName} onChange={(e) => setNewOperatorName(e.target.value)} placeholder="Ej. Juan Pérez" required className="mt-1 w-full p-2 border border-gray-300 rounded-md"/>
                         </div>
                         <div>
                            <label htmlFor="new-transportista" className="block text-sm font-medium text-gray-700">Empresa Transportista</label>
                            <input id="new-transportista" type="text" value={newOperatorTransportista} onChange={(e) => setNewOperatorTransportista(e.target.value)} placeholder="Ej. Logística del Norte" required className="mt-1 w-full p-2 border border-gray-300 rounded-md"/>
                         </div>
                     </div>
                )}
                {foundOperator && (
                    <div className="mt-2 p-2 bg-green-100 rounded">
                        <p><strong>Operador:</strong> {foundOperator.name}</p>
                        <p><strong>Empresa:</strong> {foundOperator.transportista}</p>
                    </div>
                )}
            </div>

            {/* Step 2: Photo Capture */}
            {(isIdStepComplete && (!isNewOperatorMode || (newOperatorName && newOperatorTransportista))) && (
                <div className={`p-4 rounded-lg border ${capturedPhoto ? 'bg-green-50 border-green-200' : 'bg-white'}`}>
                    <h4 className="font-semibold text-gray-700">Paso 2: Verificación Biométrica</h4>
                     <div className="w-full p-4 mt-2 border-2 border-dashed rounded-lg bg-white text-center">
                        {!isCameraActive && !capturedPhoto && (
                            <button type="button" onClick={handleStartCamera} className="action-button-verification">Iniciar Verificación con Foto</button>
                        )}
                        {isCameraActive && (
                            <div>
                                <video ref={videoRef} className="w-full rounded-md" autoPlay playsInline muted/>
                                <button type="button" onClick={handleCapturePhoto} className="mt-2 action-button-verification">Capturar Foto</button>
                            </div>
                        )}
                         {capturedPhoto && (
                            <div className="flex flex-col items-center">
                                <img src={capturedPhoto} alt="Foto Capturada" className="w-32 h-32 rounded-full object-cover border-4 border-green-200 shadow-lg" />
                                <p className="text-sm text-green-600 font-medium my-2">✓ Verificación completada</p>
                            </div>
                        )}
                        {cameraError && <p className="text-red-500 text-sm mt-1">{cameraError}</p>}
                        <canvas ref={canvasRef} className="hidden" />
                    </div>
                </div>
            )}
            
            {/* Step 3: Quiz */}
            {capturedPhoto && (
                 <div className={`p-4 rounded-lg border ${quizStatus === 'passed' ? 'bg-green-50 border-green-200' : 'bg-white'}`}>
                    <h4 className="font-semibold text-gray-700">Paso 3: Cuestionario de Validación</h4>
                    {quizStatus === 'pending' && (
                        <div className="space-y-4 mt-2">
                            {currentQuestions.map((q, index) => (
                                <div key={index}>
                                    <p className="font-medium">{index + 1}. {q.question}</p>
                                    <div className="space-y-1 mt-1">
                                        {q.options.map(opt => (
                                            <label key={opt} className="flex items-center space-x-2">
                                                <input type="radio" name={q.question} value={opt} onChange={() => handleAnswerChange(q.question, opt)} className="h-4 w-4" />
                                                <span>{opt}</span>
                                            </label>
                                        ))}
                                    </div>
                                </div>
                            ))}
                            <button type="button" onClick={handleValidateQuiz} className="action-button-verification">Validar Respuestas</button>
                        </div>
                    )}
                     {quizStatus === 'failed' && (
                        <div className="text-center p-4 bg-red-100 rounded">
                            <p className="font-semibold text-red-700">Respuestas incorrectas. Por favor, intente de nuevo.</p>
                            <button type="button" onClick={handleRetryQuiz} className="mt-2 action-button-verification bg-red-600 hover:bg-red-700">Reintentar Cuestionario</button>
                        </div>
                    )}
                    {quizStatus === 'passed' && (
                        <div className="text-center p-4 bg-green-100 rounded">
                            <p className="font-semibold text-green-700">¡Cuestionario aprobado con éxito!</p>
                        </div>
                    )}
                </div>
            )}

            {/* Step 4: Submit */}
            <div className="flex flex-col items-center space-y-2">
                <button type="submit" className="w-full px-4 py-3 bg-blue-600 text-white font-semibold rounded-md hover:bg-blue-700 disabled:bg-gray-400" disabled={quizStatus !== 'passed'}>
                    Registrar Asistencia de Operador
                </button>
                <button type="button" onClick={resetForm} className="text-sm text-gray-600 hover:text-gray-800 hover:underline">
                    Limpiar y Empezar de Nuevo
                </button>
            </div>

             <style>{`.action-button-verification { background-color: #4f46e5; color: white; font-weight: 500; padding: 0.5rem 1rem; border-radius: 0.375rem; transition: all 0.2s; white-space: nowrap; } .action-button-verification:hover { background-color: #4338ca; } .action-button-verification:disabled { background-color: #a5b4fc; cursor: not-allowed; }`}</style>
        </form>
    );
};

export default OperatorRegistrationForm;