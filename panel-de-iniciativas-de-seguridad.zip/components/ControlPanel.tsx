import React, { useState } from 'react';
import OperatorRegistrationForm from './OperatorRegistrationForm';
import RegisteredOperatorsList from './RegisteredOperatorsList';
import VerificationControl from './VerificationControl';
import { RegisteredOperator, ControlTab, OperatorRecord } from '../types';
import { OPERATOR_DATABASE } from '../operatorDatabase';


const ControlPanel: React.FC = () => {
    const [operators, setOperators] = useState<RegisteredOperator[]>([]);
    const [operatorDB, setOperatorDB] = useState<OperatorRecord[]>(OPERATOR_DATABASE);
    const [activeTab, setActiveTab] = useState<ControlTab>(ControlTab.Registro);

    const handleRegister = (operator: RegisteredOperator) => {
        setOperators(prev => [operator, ...prev]);
        alert(`Operador "${operator.name}" registrado con éxito.`);
        setActiveTab(ControlTab.Asistentes); // Switch to show the new registration
    };

    const handleAddNewOperatorToDB = (newOperator: OperatorRecord) => {
        setOperatorDB(prev => {
            // Avoid adding duplicates if user somehow triggers this twice
            if (prev.some(op => op.id === newOperator.id)) {
                return prev;
            }
            return [...prev, newOperator];
        });
    };

    const getTabClass = (tab: ControlTab) => {
        return activeTab === tab
            ? 'px-4 py-2 font-semibold text-white bg-blue-600 rounded-t-lg'
            : 'px-4 py-2 font-semibold text-gray-600 bg-gray-200 hover:bg-gray-300 rounded-t-lg';
    };

    return (
        <section className="p-6 bg-white rounded-lg shadow-md border border-gray-200">
             <div className="text-left max-w-3xl mx-auto mb-6">
                <h2 className="text-2xl font-semibold text-gray-800 mb-3">Panel de Control Interactivo</h2>
                <p className="text-gray-600">Utilice las pestañas para registrar operadores, simular el flujo de verificación de unidades o exportar la lista de asistentes.</p>
            </div>
            
            <div className="border-b border-gray-200 mb-6">
                <nav className="-mb-px flex space-x-2" aria-label="Tabs">
                    <button onClick={() => setActiveTab(ControlTab.Registro)} className={getTabClass(ControlTab.Registro)}>
                        Registro de Operador
                    </button>
                    <button onClick={() => setActiveTab(ControlTab.Verificacion)} className={getTabClass(ControlTab.Verificacion)}>
                        Control de Verificación
                    </button>
                    <button onClick={() => setActiveTab(ControlTab.Asistentes)} className={getTabClass(ControlTab.Asistentes)}>
                        Asistentes Registrados ({operators.length})
                    </button>
                </nav>
            </div>

            <div>
                {activeTab === ControlTab.Registro && <OperatorRegistrationForm onRegister={handleRegister} onAddNewOperator={handleAddNewOperatorToDB} operatorDB={operatorDB} />}
                {activeTab === ControlTab.Verificacion && <VerificationControl />}
                {activeTab === ControlTab.Asistentes && <RegisteredOperatorsList operators={operators} />}
            </div>
        </section>
    );
};

export default ControlPanel;