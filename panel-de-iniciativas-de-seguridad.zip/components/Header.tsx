
import React from 'react';

const Header: React.FC = () => {
    return (
        <header className="text-center mb-10">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">Iniciativas de Seguridad y Antifraude</h1>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">Exploración interactiva de "candados" para cursos de operadores y verificaciones de unidades.</p>
        </header>
    );
};

export default Header;
