
import React from 'react';

const Footer: React.FC = () => {
    return (
        <footer className="mt-12 pt-8 border-t border-gray-200 text-center">
            <p className="text-gray-600">Esta implementación tecnológica se traduce en un <strong>sistema a prueba de fraude</strong>, incrementando drásticamente la fiabilidad de las certificaciones y la seguridad vial.</p>
        </footer>
    );
};

export default Footer;
