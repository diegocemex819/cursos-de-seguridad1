import React, { useState, useEffect, useRef, useCallback } from 'react';

const VerificationControl: React.FC = () => {
    const [unitId, setUnitId] = useState('');
    const [isScanned, setIsScanned] = useState(false);
    const [isPhotographed, setIsPhotographed] = useState(false);
    const [isVerified, setIsVerified] = useState(false);
    const [statusMessage, setStatusMessage] = useState('Esperando inicio de verificación...');
    const [isLoading, setIsLoading] = useState(false);
    const [isAbsent, setIsAbsent] = useState(false);

    // Camera state
    const [isCameraActive, setIsCameraActive] = useState(false);
    const [stream, setStream] = useState<MediaStream | null>(null);
    const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
    const [error, setError] = useState('');

    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);

    const stopCameraStream = useCallback(() => {
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
            setStream(null);
            setIsCameraActive(false);
        }
    }, [stream]);

    useEffect(() => {
        if (isCameraActive && stream && videoRef.current) {
            videoRef.current.srcObject = stream;
            videoRef.current.play().catch(err => console.error("Error playing video:", err));
        }
        return () => {
            if (stream) {
                stopCameraStream();
            }
        };
    }, [isCameraActive, stream, stopCameraStream]);

    const resetState = () => {
        setUnitId('');
        setIsScanned(false);
        setIsPhotographed(false);
        setIsVerified(false);
        setStatusMessage('Esperando inicio de verificación...');
        setIsLoading(false);
        setIsAbsent(false);
        setCapturedPhoto(null);
        setError('');
        stopCameraStream();
    };

    const handleScan = () => {
        if (!unitId.trim()) {
            setStatusMessage('Error: Ingrese un ID de unidad para escanear.');
            return;
        }
        setIsLoading(true);
        setStatusMessage(`Escaneando unidad ${unitId}...`);
        setTimeout(() => {
            setIsScanned(true);
            setStatusMessage(`Éxito: Unidad ${unitId} escaneada (Iniciativa 4). Listo para tomar evidencia fotográfica.`);
            setIsLoading(false);
        }, 1500);
    };

    const handleStartCamera = async () => {
        try {
            setError('');
            const mediaStream = await navigator.mediaDevices.getUserMedia({ video: true });
            setStream(mediaStream);
            setIsCameraActive(true);
        } catch (err) {
            console.error("Error accessing camera:", err);
            setError("No se pudo acceder a la cámara. Verifique los permisos.");
        }
    };

    const handleCapturePhoto = () => {
        if (videoRef.current && canvasRef.current) {
            const video = videoRef.current;
            const canvas = canvasRef.current;
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            const context = canvas.getContext('2d');
            context?.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
            setCapturedPhoto(canvas.toDataURL('image/jpeg'));
            setIsPhotographed(true);
            setStatusMessage('Éxito: Evidencia fotográfica capturada (Iniciativa 5). Listo para validación final.');
            stopCameraStream();
        }
    };
    
    const handleRetakePhoto = () => {
        setCapturedPhoto(null);
        setIsPhotographed(false);
        setStatusMessage(`Listo para tomar evidencia fotográfica para la unidad ${unitId}.`);
        handleStartCamera();
    };


    const handleVerify = () => {
        setIsLoading(true);
        setStatusMessage('Integrando sistemas y validando datos...');
        setTimeout(() => {
            setIsVerified(true);
            setStatusMessage(`Éxito: Verificación completa (Iniciativa 6). Se puede iniciar la inspección de la unidad ${unitId}.`);
            setIsLoading(false);
        }, 1500);
    };

    const isStep1Disabled = isScanned || isLoading || isAbsent;
    const isStep2Disabled = !isScanned || isPhotographed || isLoading || isAbsent;
    const isStep3Disabled = !isPhotographed || isVerified || isLoading || isAbsent;

    return (
        <div className="p-6 bg-gray-50 rounded-lg shadow-inner border">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Simulador de Flujo de Verificación</h3>

            <div className="space-y-6">
                {/* Step 1: Scan */}
                <div className={`p-4 rounded-lg border ${isScanned ? 'bg-green-50 border-green-200' : 'bg-white'}`}>
                    <h4 className="font-semibold text-gray-700">Paso 1: Escaneo de Identidad Única (RFID/QR)</h4>
                    <p className="text-sm text-gray-500 mb-3">Simula la llegada de la unidad y el escaneo de su identificador único.</p>
                    <div className="flex items-center space-x-3">
                         <input
                            type="text"
                            value={unitId}
                            onChange={(e) => setUnitId(e.target.value.toUpperCase())}
                            className="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 disabled:bg-gray-200"
                            placeholder="ID de Unidad (Ej. ABC-123)"
                            disabled={isStep1Disabled}
                        />
                        <button onClick={handleScan} disabled={isStep1Disabled || !unitId.trim()} className="action-button-verification" >
                            Escanear
                        </button>
                    </div>
                </div>

                {/* Step 2: Photo */}
                <div className={`p-4 rounded-lg border ${isPhotographed ? 'bg-green-50 border-green-200' : 'bg-white'}`}>
                     <h4 className="font-semibold text-gray-700">Paso 2: Evidencia Fotográfica</h4>
                     <p className="text-sm text-gray-500 mb-3">Captura de evidencia visual en tiempo real para garantizar la presencia de la unidad.</p>
                     
                     <div className="w-full p-4 border-2 border-dashed rounded-lg bg-white text-center">
                        {!isCameraActive && !capturedPhoto && (
                            <button type="button" onClick={handleStartCamera} className="action-button-verification" disabled={isStep2Disabled}>
                                Iniciar Cámara para Evidencia
                            </button>
                        )}
                        {isCameraActive && !capturedPhoto && (
                            <div>
                                <video ref={videoRef} className="w-full rounded-md" autoPlay playsInline />
                                <button type="button" onClick={handleCapturePhoto} className="mt-2 action-button-verification">
                                    Capturar Evidencia
                                </button>
                            </div>
                        )}
                        {capturedPhoto && (
                             <div className="flex flex-col items-center">
                                <img src={capturedPhoto} alt="Evidencia Capturada" className="w-48 h-auto rounded-md border" />
                                <p className="text-sm text-green-600 font-medium my-2">✓ Evidencia capturada</p>
                                <button type="button" onClick={handleRetakePhoto} className="text-sm text-blue-600 hover:underline" disabled={isVerified}>
                                    Tomar Otra Foto
                                </button>
                            </div>
                        )}
                        <canvas ref={canvasRef} className="hidden"></canvas>
                        {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
                    </div>
                </div>

                {/* Step 3: Verify */}
                <div className={`p-4 rounded-lg border ${isVerified ? 'bg-green-50 border-green-200' : 'bg-white'}`}>
                    <h4 className="font-semibold text-gray-700">Paso 3: Integración y Validación de Sistemas</h4>
                    <p className="text-sm text-gray-500 mb-3">Simula la validación automática del sistema antes de permitir el inicio de la inspección.</p>
                    <button onClick={handleVerify} disabled={isStep3Disabled} className="action-button-verification">
                        Validar
                    </button>
                </div>
            </div>

            {/* Status Panel */}
            <div className={`mt-6 p-4 rounded-lg text-center font-medium
                ${isVerified ? 'bg-green-100 text-green-800 border border-green-200' : ''}
                ${isAbsent ? 'bg-red-100 text-red-800 border border-red-200' : ''}
                ${!isVerified && !isAbsent ? 'bg-blue-100 text-blue-800 border border-blue-200' : ''}
            `}>
                <p><strong>Estado:</strong> {isLoading ? 'Procesando...' : statusMessage}</p>
            </div>
            
            <div className="mt-6 text-center">
                <button onClick={resetState} className="text-sm text-gray-600 hover:text-gray-800 hover:underline">
                    Reiniciar Simulación
                </button>
            </div>
            <style>{`.action-button-verification { background-color: #4f46e5; color: white; font-weight: 500; padding: 0.5rem 1rem; border-radius: 0.375rem; transition: all 0.2s; white-space: nowrap; } .action-button-verification:hover { background-color: #4338ca; } .action-button-verification:disabled { background-color: #a5b4fc; cursor: not-allowed; }`}</style>
        </div>
    );
};

export default VerificationControl;