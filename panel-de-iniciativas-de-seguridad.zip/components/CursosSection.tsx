
import React from 'react';
import { CURSOS_INITIATIVES } from '../constants';
import InitiativeCard from './InitiativeCard';

const CursosSection: React.FC = () => {
    return (
        <section>
            <div className="text-left max-w-3xl mx-auto mb-8">
                <h2 className="text-2xl font-semibold text-gray-800 mb-3">Candados para Cursos (Garantía de Asistencia)</h2>
                <p className="text-gray-600">El objetivo es asegurar, mediante verificación multifactor, que la persona inscrita esté activamente presente durante toda la duración del curso. A continuación se presentan 3 iniciativas clave.</p>
            </div>
            <div className="grid md:grid-cols-1 lg:grid-cols-3 gap-6">
                {CURSOS_INITIATIVES.map(initiative => (
                    <InitiativeCard key={initiative.id} initiative={initiative} />
                ))}
            </div>
        </section>
    );
};

export default CursosSection;
