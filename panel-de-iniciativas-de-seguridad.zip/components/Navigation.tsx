import React from 'react';
import { Section } from '../types';

interface NavigationProps {
    activeSection: Section;
    setActiveSection: (section: Section) => void;
}

const Navigation: React.FC<NavigationProps> = ({ activeSection, setActiveSection }) => {
    const getButtonClasses = (section: Section): string => {
        const baseClasses = "w-full px-4 py-3 text-lg font-medium text-center text-gray-600 bg-white border border-gray-200 rounded-lg shadow-sm cursor-pointer hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-200";
        if (activeSection === section) {
            return `${baseClasses} bg-blue-600 text-white hover:bg-blue-700 border-blue-600 shadow-md`;
        }
        return baseClasses;
    };

    return (
        <nav className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-10 max-w-4xl mx-auto">
            <button 
                className={getButtonClasses(Section.Cursos)} 
                onClick={() => setActiveSection(Section.Cursos)}
            >
                1. Cursos de Operadores
            </button>
            <button 
                className={getButtonClasses(Section.Verificaciones)} 
                onClick={() => setActiveSection(Section.Verificaciones)}
            >
                2. Verificaciones de Unidades
            </button>
            <button 
                className={getButtonClasses(Section.Control)} 
                onClick={() => setActiveSection(Section.Control)}
            >
                ⚙️ Panel de Control
            </button>
        </nav>
    );
};

export default Navigation;
